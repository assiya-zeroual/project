import pandas as pd
from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
import os
from docx2pdf import convert  # pip install docx2pdf

# Charger le CSV
df = pd.read_csv("users_info.csv")

# Créer le dossier de sortie
output_dir = "CVs"
os.makedirs(output_dir, exist_ok=True)

def create_modern_cv(row):
    doc = Document()

    # STYLE global
    style = doc.styles["Normal"]
    font = style.font
    font.name = "Calibri"
    font.size = Pt(11)

    # Photo (zone vide)
    p = doc.add_paragraph()
    p.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    run = p.add_run("[Insérer votre photo ici]")
    run.bold = True
    run.font.size = Pt(12)

    # Nom et email
    doc.add_heading(f"{row['Prénom']} {row['Nom']}", level=0)
    doc.add_paragraph(f"Email : {row['Email']}")

    # Objectif professionnel
    doc.add_heading("🎯 Objectif Professionnel", level=1)
    doc.add_paragraph("[À compléter : Décrivez ici brièvement vos objectifs professionnels]")

    # Formation
    doc.add_heading("🎓 Formation", level=1)
    doc.add_paragraph(row['Formation'])

    # Expérience
    doc.add_heading("💼 Expérience Professionnelle", level=1)
    doc.add_paragraph(row['Expérience professionnelle'])

    # Compétences
    doc.add_heading("🧠 Compétences", level=1)
    doc.add_paragraph(row['Compétences'])

    # Enregistrer le fichier Word
    filename_docx = f"{row['Prénom']}_{row['Nom']}_CV.docx"
    path_docx = os.path.join(output_dir, filename_docx)
    doc.save(path_docx)

    # Convertir en PDF
    path_pdf = path_docx.replace(".docx", ".pdf")
    convert(path_docx, path_pdf)

    print(f"✅ CV Word + PDF générés pour {row['Prénom']} {row['Nom']}")

# Générer tous les CV
for _, row in df.iterrows():
    create_modern_cv(row)
