import pandas as pd
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# Charger les fichiers
df_users = pd.read_excel("users.xlsx")
df_links = pd.read_excel("results.xlsx")

# Corriger les noms de domaine
corrections = {
    "Communication / Marketing": "Marketing",
    "IT / Software": "IT / Software",
    "IT / software": "IT / Software",
    "HR": "HR"
}
df_users["Domaine"] = df_users["Domaine"].replace(corrections)

# Configuration SMTP (exemple Gmail)
SMTP_SERVER = 'smtp.gmail.com'
SMTP_PORT = 587
EMAIL_ADDRESS = 'tabathafssa@gmail.com'         # Remplace par ton email
EMAIL_PASSWORD = 'bsgm nwmu dggp pvug'   # Remplace par ton mot de passe d'application

# Créer une connexion SMTP
server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
server.starttls()
server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)

# Envoyer des emails
for _, user in df_users.iterrows():
    user_email = user["email"].replace(",", ".")  # Correction d'erreur fréquente
    user_domain = user["Domaine"]
    user_name = user["Prenom"]

    # Récupérer les liens du domaine
    links = df_links[df_links["Domaine"] == user_domain]["Lien"].tolist()

    if links:
        # Construire le message
        msg = MIMEMultipart()
        msg["From"] = EMAIL_ADDRESS
        msg["To"] = user_email
        msg["Subject"] = f"Offres d'emploi dans votre domaine : {user_domain}"

        body = f"Bonjour {user_name},\n\nVoici les dernières offres d'emploi dans le domaine {user_domain} :\n\n"
        for link in links:
            body += f"- {link}\n"
        body += "\nBonne chance dans votre recherche !\n"

        msg.attach(MIMEText(body, "plain"))

        # Envoyer l'email
        try:
            server.send_message(msg)
            print(f"Email envoyé à {user_email}")
        except Exception as e:
            print(f"Échec de l'envoi à {user_email}: {e}")

# Fermer la connexion
server.quit()
