import pandas as pd
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# --- Charger les fichiers Excel ---
df_users = pd.read_excel("users.xlsx")
df_links = pd.read_excel("results.xlsx")

# --- Harmonisation des domaines ---
corrections = {
    "Communication / Marketing": "Marketing",
    "IT / software": "IT / Software",
    "IT / Software": "IT / Software",
    "HR": "HR",
    "Hospitality": "Hospitality",
    "Construction": "Construction",
    "Administration / Office Support": "Administration / Office Support"
}
df_users["Domaine"] = df_users["Domaine"].replace(corrections)

# --- Configuration SMTP (Gmail) ---
SMTP_SERVER = 'smtp.gmail.com'
SMTP_PORT = 587
EMAIL_ADDRESS = 'tabathafssa@gmail.com'       # Remplace par ton email
EMAIL_PASSWORD = 'xxxxxxxxxxx'         # Mot de passe d'application Gmail

# --- Connexion au serveur SMTP ---
server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
server.starttls()
server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)

# --- Envoi des emails personnalisés ---
for _, user in df_users.iterrows():
    user_email = user["email"].replace(",", ".")
    user_domain = user["Domaine"]
    user_name = user["Prenom"]

    # Liens correspondant au domaine
    links = df_links[df_links["Domaine"] == user_domain]["Lien"].tolist()
    if not links:
        continue

    # --- Message Email ---
    msg = MIMEMultipart("alternative")
    msg["From"] = EMAIL_ADDRESS
    msg["To"] = user_email
    msg["Subject"] = f"Offres d'emploi dans votre domaine : {user_domain}"

    # --- Contenu HTML stylisé ---
    body_html = f"""
    <html>
    <head>
      <style>
        body {{
          background-color: #f1f5f9;
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          padding: 40px 0;
          margin: 0;
        }}
        .container {{
          background-color: #ffffff;
          max-width: 650px;
          margin: auto;
          padding: 30px;
          border-radius: 10px;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
          border-left: 8px solid #2a9d8f;
        }}
        h1 {{
          color: #264653;
          text-align: center;
          margin-bottom: 25px;
          font-size: 24px;
        }}
        p {{
          font-size: 16px;
          color: #1e293b;
          line-height: 1.6;
        }}
        .button {{
          display: inline-block;
          padding: 10px 20px;
          margin: 8px 4px;
          background-color: #2a9d8f;
          color: #fff;
          text-decoration: none;
          border-radius: 6px;
          font-weight: bold;
          transition: background-color 0.3s ease;
        }}
        .button:hover {{
          background-color: #21867a;
        }}
        .footer {{
          margin-top: 35px;
          font-size: 13px;
          color: #6b7280;
          text-align: center;
        }}
      </style>
    </head>
    <body>
      <div class="container">
        <h1>🎯 Opportunités Correspondant à Votre Profil</h1>
        <p>Bonjour {user_name},</p>
        <p>
          Vous trouverez ci-dessous une sélection d’offres d’emploi correspondant à votre domaine : <strong>{user_domain}</strong>.
        </p>
    """

    # Ajouter les liens sous forme de boutons
    for link in links:
        body_html += f'<a href="{link}" class="button" target="_blank">Voir l’offre</a>'

    body_html += f"""
        <p>Nous vous souhaitons une excellente réussite dans votre parcours professionnel.</p>
        <div class="footer">
          Bien cordialement,<br>
          <strong>Équipe Recrutement</strong><br>
          [Votre Organisation]
        </div>
      </div>
    </body>
    </html>
    """

    # Attacher le contenu HTML
    msg.attach(MIMEText(body_html, "html", "utf-8"))

    # --- Envoyer ---
    try:
        server.send_message(msg)
        print(f"✅ Email envoyé à {user_email}")
    except Exception as e:
        print(f"❌ Erreur pour {user_email} : {e}")

# --- Fermer la connexion ---
server.quit()
