import pandas as pd
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
import os
from docx2pdf import convert

# Charger le CSV
df = pd.read_csv("users_info.csv")

# Créer le dossier de sortie
output_dir = "Lettres_Motivation"
os.makedirs(output_dir, exist_ok=True)

def create_letter(row):
    doc = Document()

    # Police générale
    style = doc.styles["Normal"]
    font = style.font
    font.name = "Calibri"
    font.size = Pt(11)

    # Entête centrée
    header = doc.add_paragraph()
    header.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    run = header.add_run(f"{row['Prénom']} {row['Nom']}\nEmail : {row['Email']}")
    run.bold = True
    run.font.size = Pt(12)

    doc.add_paragraph("\n[Nom de l’entreprise]")
    doc.add_paragraph("[Adresse de l’entreprise]")
    doc.add_paragraph("")

    # Date
    doc.add_paragraph("Fait à ..., le [Date]")

    # Objet
    doc.add_heading("Objet : [À compléter – Candidature au poste de ...]", level=2)

    # Contenu
    doc.add_paragraph(
        "Madame, Monsieur,\n\n"
        "[À compléter – Parlez de la motivation personnelle pour le poste visé.]\n\n"
        f"Ayant suivi une formation en {row['Formation'].split(',')[0]}, "
        f"et fort(e) d'une expérience en {row['Expérience professionnelle']}, "
        "je souhaite mettre à profit mes compétences, notamment en "
        f"{row['Compétences'].split(',')[0]}, au sein de votre entreprise.\n\n"
        "Je reste à votre disposition pour tout entretien afin de vous exposer "
        "ma motivation plus en détail.\n\nVeuillez agréer, Madame, Monsieur, "
        "l’expression de mes salutations distinguées."
    )

    # Signature
    doc.add_paragraph("\n\nSignature : ___________________")

    # Sauvegarde
    filename = f"{row['Prénom']}_{row['Nom']}_Lettre.docx"
    filepath_docx = os.path.join(output_dir, filename)
    doc.save(filepath_docx)

    # Convertir en PDF
    filepath_pdf = filepath_docx.replace(".docx", ".pdf")
    convert(filepath_docx, filepath_pdf)

    print(f"📄 Lettre générée : {filename}")

# Générer les lettres pour tous les utilisateurs
for _, row in df.iterrows():
    create_letter(row)
